from sys import argv
from json import dumps
conf = {
    "log": {
        "loglevel": "info"
    },
    "inbounds": [
        {
            "port": 40000,
            "protocol": "vmess",
            "settings": {
                "clients": [
                    {
                        "id": "41e3958d-3231-4ea9-851a-b0a1707867ee",
                        "level": 0,
                        "alterId": 0
                    }
                ]
            },
            "streamSettings": {
                "network": "tcp",
                "security": "none"
            },
            "tag": "1"
        },
        {
            "port": 40001,
            "protocol": "vmess",
            "settings": {
                "clients": [
                    {
                        "id": "41e3958d-3231-4ea9-851a-b0a1707867ee",
                        "level": 0,
                        "alterId": 0
                    }
                ]
            },
            "streamSettings": {
                "network": "tcp",
                "security": "none"
            },
            "tag": "2"
        }
    ],
    "outbounds": [
        {
            "sendThrough": argv[0],
            "protocol": "Freedom",
            "tag": "1"
        },
        {
            "sendThrough": argv[1],
            "protocol": "Freedom",
            "tag": "2"
        }
    ],
    "routing": {
        "rules": [
            {
                "type": "field",
                "inboundTag": [
                    "1"
                ],
                "outboundTag": "1"
            },
            {
                "type": "field",
                "inboundTag": [
                    "2",
                    "3"
                ],
                "outboundTag": "2"
            },
            {
                "ip": [
                    "geoip:private"
                ],
                "outboundTag": "blocked",
                "type": "field"
            }
        ]
    }
}
with open("/root/x/config.json", "w") as f:
    f.write(dumps(conf))
